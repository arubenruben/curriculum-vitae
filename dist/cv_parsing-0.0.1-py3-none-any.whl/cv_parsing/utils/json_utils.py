import os
from json_repair import repair_json as rp
from cv_parsing.exceptions.JSONException import JSONException
from environs import Env

env = Env(eager=True)
env.read_env()

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

ROOT_PATH = os.path.realpath(__file__).split('src')[0]

SCHEMA_PATH = os.path.join(
    ROOT_PATH, "data", "schema.jsonl") if 'SCHEMA_PATH' not in os.environ.keys() else env('SCHEMA_PATH')

# The schema must be load using open() because json.load() would not preserve the comments in the JSON file
with open(SCHEMA_PATH, 'r', encoding='utf-8') as f:
    JSON_STR = f.read()

SCHEMA_DICT = rp(JSON_STR, return_objects=True)

print(SCHEMA_DICT)

def repair_json(json_str) -> dict:
    if json_str == "":
        raise JSONException("Empty JSON string")

    # Consider all text after the first '{' as a JSON object and the last '}' as the end of the JSON object
    first_bracket = json_str.find('{')
    last_bracket = json_str.rfind('}')

    if first_bracket == -1 or last_bracket == -1:
        raise JSONException("Invalid JSON string")

    return rp(json_str[first_bracket:last_bracket+1], return_objects=True)
